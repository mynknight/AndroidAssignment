package com.example.library.ui.home;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import com.example.library.Book;
import com.example.library.BookAdapter;
import com.example.library.R;
public class HomeFragment extends Fragment implements BookAdapter.OnBookActionListener {

    private RecyclerView recyclerView;
    private BookAdapter adapter;
    private ArrayList<Book> bookList;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Initialize RecyclerView
        recyclerView = view.findViewById(R.id.recyclerView);
        setupRecyclerView();

        // Create and populate book data
        createBookData();

        // Setup adapter
        setupAdapter();

        return view;
    }

    private void setupRecyclerView() {
        // Set horizontal layout manager
        LinearLayoutManager layoutManager = new LinearLayoutManager(
                getContext(),
                LinearLayoutManager.HORIZONTAL,
                false
        );
        recyclerView.setLayoutManager(layoutManager);
    }

    private void createBookData() {
        bookList = new ArrayList<>();

        // Add sample books with enhanced data
        bookList.add(new Book(
                "The Great Gatsby",
                String.valueOf(R.drawable.book_placeholder),
                "A classic American novel about the Jazz Age and the American Dream."
        ));

        bookList.add(new Book(
                "To Kill a Mockingbird",
                String.valueOf(R.drawable.book_placeholder),
                "A gripping tale of racial injustice and childhood in the American South."
        ));

        bookList.add(new Book(
                "1984",
                String.valueOf(R.drawable.book_placeholder),
                "George Orwell's dystopian social science fiction novel and cautionary tale."
        ));

        bookList.add(new Book(
                "Pride and Prejudice",
                String.valueOf(R.drawable.book_placeholder),
                "Jane Austen's romantic novel about manners, upbringing, and marriage."
        ));

        bookList.add(new Book(
                "The Catcher in the Rye",
                String.valueOf(R.drawable.book_placeholder),
                "J.D. Salinger's novel about teenage rebellion and alienation."
        ));
    }

    private void setupAdapter() {
        adapter = new BookAdapter(bookList);
        adapter.setOnBookActionListener(this);
        recyclerView.setAdapter(adapter);
    }

    // Handle card clicks
    @Override
    public void onBookClick(Book book, int position) {
        Toast.makeText(getContext(),
                "Selected: " + book.getTitle(),
                Toast.LENGTH_SHORT).show();

        // Here you can navigate to book details, etc.
        // Example: startActivity or replace fragment
    }

    // Handle button clicks
    @Override
    public void onBookButtonClick(Book book, int position) {
        Toast.makeText(getContext(),
                "Button clicked for: " + book.getTitle(),
                Toast.LENGTH_SHORT).show();

        // Handle button specific actions like:
        // - Add to favorites
        // - Add to reading list
        // - Share book
        // - Download book
        handleBookAction(book, position);
    }

    private void handleBookAction(Book book, int position) {
        // Implement your specific button action here
        // For example:
        switch (position % 3) {
            case 0:
                // Add to favorites
                showMessage("Added '" + book.getTitle() + "' to favorites");
                break;
            case 1:
                // Add to reading list
                showMessage("Added '" + book.getTitle() + "' to reading list");
                break;
            case 2:
                // Share book
                showMessage("Sharing '" + book.getTitle() + "'");
                break;
        }
    }

    private void showMessage(String message) {
        Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
    }

    // Method to refresh data if needed
    public void refreshBooks() {
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }

    // Method to add new book
    public void addBook(Book book) {
        if (bookList != null && adapter != null) {
            bookList.add(book);
            adapter.notifyItemInserted(bookList.size() - 1);
        }
    }
}