package com.example.library.data.local.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.library.data.local.entity.BookEntity;

import java.util.List;

@Dao
public interface BookDao {

    @Query("SELECT * FROM books")
    LiveData<List<BookEntity>> getAllBooks();
    @Query("SELECT COUNT(*) FROM books")
    int getCount();
    @Query("SELECT * FROM books WHERE id = :bookId")
    LiveData<BookEntity> getBookById(String bookId);

    @Update
    void updateBook(BookEntity book);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<BookEntity> books);
}
