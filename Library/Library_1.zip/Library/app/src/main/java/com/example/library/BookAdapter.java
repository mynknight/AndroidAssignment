package com.example.library;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.BookViewHolder> {

    private ArrayList<Book> bookList;
    private OnBookActionListener listener;

    // Interface for handling button clicks
    public interface OnBookActionListener {
        void onBookClick(Book book, int position);
        void onBookButtonClick(Book book, int position);
    }

    public BookAdapter(ArrayList<Book> bookList) {
        this.bookList = bookList;
    }

    public void setOnBookActionListener(OnBookActionListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public BookViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_book_card, parent, false);
        return new BookViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BookViewHolder holder, int position) {
        Book book = bookList.get(position);
        holder.bind(book, position);
    }

    @Override
    public int getItemCount() {
        return bookList.size();
    }

    public class BookViewHolder extends RecyclerView.ViewHolder {
        private ImageView bookImage;
        private TextView bookTitle;
        private TextView bookDescription;
        private Button actionButton;

        public BookViewHolder(@NonNull View itemView) {
            super(itemView);
            bookImage = itemView.findViewById(R.id.book_image);
            bookTitle = itemView.findViewById(R.id.book_title);
            bookDescription = itemView.findViewById(R.id.book_description);
            actionButton = itemView.findViewById(R.id.action_button);
        }

        public void bind(Book book, int position) {
            bookTitle.setText(book.getTitle());
            bookDescription.setText(book.getDescription());

            // Load image - you can use libraries like Glide or Picasso for URLs
            // For now, using placeholder or resource ID
            if (book.getImageUrl() != null && !book.getImageUrl().isEmpty()) {
                // If using resource ID (for placeholder)
                try {
                    int resourceId = Integer.parseInt(book.getImageUrl());
                    bookImage.setImageResource(resourceId);
                } catch (NumberFormatException e) {
                    // If it's a URL, you would use Glide/Picasso here
                    // Glide.with(itemView.getContext()).load(book.getImageUrl()).into(bookImage);
                    bookImage.setImageResource(R.drawable.book_placeholder);
                }
            } else {
                bookImage.setImageResource(R.drawable.book_placeholder);
            }

            // Handle card click
            itemView.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onBookClick(book, position);
                }
            });

            // Handle button click
            actionButton.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onBookButtonClick(book, position);
                }
            });
        }
    }
}
